# SEP Team 5
## Software Sherlock

Unser bisheriger Prototyp stellt folgende Funktionen bereit:

**Einloggen** - Bei Eingabe des Nutzernamens und des richtigen
Passwortes wird ein Datenbankabgleich durchgeführt und dessen
Ergebnis widergegeben. Bei falscher Eingabe wird ebenfalls eine
Fehlermeldung angezeigt. Bei richtiger Eingabe wird eine
Successnachricht angezeigt. (Möglicher login: victor, password)

**Registrierung** - hierbei wird lediglich auf der
Registrationsseite (bei klicken auf register) an die angegebene
Email eine Nachricht gesendet.

**File Upload** - Hier können leider nur PNGs hochgeladen werden,
diese werden gespeichert und angezeigt. Hier ist noch kein
ErrorHandling implementiert.

Noch zur Info: leeeonn ist der gleiche Nutzer wie Hoefling und
leonf der gleiche wie Leon Föckersperger
