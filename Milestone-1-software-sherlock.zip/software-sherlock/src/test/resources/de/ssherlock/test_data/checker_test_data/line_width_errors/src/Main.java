public class Main {
    public static void main(String[] args) {
        Person person = new Person("Victor", 12);
        System.out.println(person.getAge());
        System.out.println("This string is way too long so please change it to be way shorter like why");
    }
}
