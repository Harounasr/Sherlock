public class Main {
    public static void main(String[] args) {
        Person person = new Person("Victor", 12);
        System.out.println(person.getAge());
    }
}
