/**
 * Package to test the business layer of the application.
 */
package de.ssherlock.business;
