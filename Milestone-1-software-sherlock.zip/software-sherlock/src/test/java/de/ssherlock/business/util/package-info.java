/**Package to test business.util classes.*/
package de.ssherlock.business.util;
