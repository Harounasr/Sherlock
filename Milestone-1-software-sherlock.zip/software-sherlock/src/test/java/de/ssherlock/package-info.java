/** Base package to test the application. */
package de.ssherlock;
