/**
 * Package for all System Tests of the application.
 */
package de.ssherlock.system_tests;
