/**
 * Package to test the control layer of the application.
 */
package de.ssherlock.control;
