/**
 * This package contains the tests for the exception classes.
 */
package de.ssherlock.control.session;
