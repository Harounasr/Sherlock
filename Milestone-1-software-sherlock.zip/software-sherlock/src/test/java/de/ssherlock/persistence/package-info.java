/**
 * Package to test the persistence layer of the application.
 */
package de.ssherlock.persistence;
