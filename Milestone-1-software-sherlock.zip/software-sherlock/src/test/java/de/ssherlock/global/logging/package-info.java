/**
 * Test classes for the global.logging package.
 */
package de.ssherlock.global.logging;
