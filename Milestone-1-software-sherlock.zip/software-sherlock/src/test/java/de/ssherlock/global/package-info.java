/**
 * Test classes for the global package.
 */
package de.ssherlock.global;
