/** Contains all DTOs for transmitting data between layers. */
package de.ssherlock.global.transport;
