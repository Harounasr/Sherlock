/** Contains classes that manage logging in the application. */
package de.ssherlock.global.logging;
