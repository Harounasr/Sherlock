/** Classes that are used in every layer. */
package de.ssherlock.global;
