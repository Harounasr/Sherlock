/** Service classes for business operations. */
package de.ssherlock.business.service;
