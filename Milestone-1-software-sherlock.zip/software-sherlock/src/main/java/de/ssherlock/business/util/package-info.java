/** Utility classes for the business layer. */
package de.ssherlock.business.util;
