/**
 * Layer that handles all business logic and operations.
 */
package de.ssherlock.business;
