/** Exceptions that are thrown in the business layer. */
package de.ssherlock.business.exception;
