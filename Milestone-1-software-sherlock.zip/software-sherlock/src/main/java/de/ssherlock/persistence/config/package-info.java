/** Contains the configuration of the persistence layer. */
package de.ssherlock.persistence.config;
