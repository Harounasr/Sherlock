/** Contains all transaction logic. */
package de.ssherlock.persistence.transaction;
