/** Utility classes for the persistence layer. */
package de.ssherlock.persistence.util;
