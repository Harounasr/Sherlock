/** Contains all DAOs for CRUD operations. */
package de.ssherlock.persistence.repository;
