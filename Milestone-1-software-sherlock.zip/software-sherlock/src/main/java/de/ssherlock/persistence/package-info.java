/** Layer that handles all database and email logic. */
package de.ssherlock.persistence;
