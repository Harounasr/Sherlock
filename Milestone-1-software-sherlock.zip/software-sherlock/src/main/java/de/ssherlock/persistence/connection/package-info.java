/** Handles and manages connections with the database. */
package de.ssherlock.persistence.connection;
