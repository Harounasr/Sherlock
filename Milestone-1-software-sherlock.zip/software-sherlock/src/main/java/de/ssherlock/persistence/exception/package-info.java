/** Exceptions that are thrown in the persistence layer. */
package de.ssherlock.persistence.exception;
