/** Contains session logic. */
package de.ssherlock.control.session;
