/** Layer that manages and handles user input. */
package de.ssherlock.control;
