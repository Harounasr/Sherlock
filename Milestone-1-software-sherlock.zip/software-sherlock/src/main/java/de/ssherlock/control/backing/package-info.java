/** Backing beans for all facelets. */
package de.ssherlock.control.backing;
