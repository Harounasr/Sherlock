/** Exceptions that are thrown in the control layer. */
package de.ssherlock.control.exception;
