/** Classes to manage feedback messages to the user. */
package de.ssherlock.control.notification;
