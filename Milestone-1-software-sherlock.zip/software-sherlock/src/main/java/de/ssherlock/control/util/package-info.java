/** Utility classes for the control layer. */
package de.ssherlock.control.util;
