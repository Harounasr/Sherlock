#!/usr/bin/env bash

# Author: Leon Föckersperger

set -e

rm -rf target* tomcat .m2
