#!/usr/bin/env bash

# Author: Leon Föckersperger

set -e

cd "${HOME}/Dev/Git/sep-team-5"
git fetch
git checkout origin/main

